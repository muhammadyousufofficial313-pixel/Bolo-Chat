ALTER TABLE `messages` ADD `media_blob_key` text;
--> statement-breakpoint
ALTER TABLE `messages` ADD `delivery_status` text DEFAULT 'sent' NOT NULL;