ALTER TABLE `profiles` ADD `theme_mode` text DEFAULT 'system' NOT NULL;
--> statement-breakpoint
UPDATE `profiles` SET `message_tone` = CASE `message_tone`
  WHEN 'chime' THEN 'saba'
  WHEN 'pulse' THEN 'raqs'
  WHEN 'soft' THEN 'sukoon'
  ELSE `message_tone`
END;
