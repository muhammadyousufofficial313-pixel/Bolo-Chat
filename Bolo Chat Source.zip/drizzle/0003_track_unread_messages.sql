ALTER TABLE `messages` ADD `read_at` integer;
--> statement-breakpoint
UPDATE `messages` SET `read_at` = `created_at` WHERE `direction` = 'self';
