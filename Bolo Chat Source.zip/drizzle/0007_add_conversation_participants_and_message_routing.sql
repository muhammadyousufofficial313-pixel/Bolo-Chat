ALTER TABLE `conversations` ADD `current_user_id` text NOT NULL DEFAULT '';
--> statement-breakpoint
ALTER TABLE `conversations` ADD `target_user_id` text NOT NULL DEFAULT '';
--> statement-breakpoint
ALTER TABLE `conversations` ADD `last_message` text;
--> statement-breakpoint
ALTER TABLE `conversations` ADD `last_message_type` text;
--> statement-breakpoint
ALTER TABLE `conversations` ADD `last_sender_id` text;
--> statement-breakpoint
ALTER TABLE `conversations` ADD `unread_count` integer NOT NULL DEFAULT 0;
--> statement-breakpoint
ALTER TABLE `messages` ADD `sender_id` text NOT NULL DEFAULT '';
--> statement-breakpoint
ALTER TABLE `messages` ADD `receiver_id` text NOT NULL DEFAULT '';
--> statement-breakpoint
UPDATE `conversations`
SET `current_user_id` = COALESCE((SELECT `email` FROM `profiles` WHERE `id` = 1), ''),
    `target_user_id` = COALESCE(NULLIF(LOWER(`contact_email`), ''), 'contact:' || `id`),
    `last_message` = (SELECT `body` FROM `messages` WHERE `conversation_id` = `conversations`.`id` ORDER BY `created_at` DESC, `id` DESC LIMIT 1),
    `last_message_type` = (SELECT `message_type` FROM `messages` WHERE `conversation_id` = `conversations`.`id` ORDER BY `created_at` DESC, `id` DESC LIMIT 1),
    `unread_count` = (SELECT COUNT(*) FROM `messages` WHERE `conversation_id` = `conversations`.`id` AND `direction` = 'contact' AND `read_at` IS NULL);
--> statement-breakpoint
UPDATE `conversations`
SET `last_sender_id` = CASE
  WHEN (SELECT `direction` FROM `messages` WHERE `conversation_id` = `conversations`.`id` ORDER BY `created_at` DESC, `id` DESC LIMIT 1) = 'self' THEN `current_user_id`
  WHEN (SELECT `direction` FROM `messages` WHERE `conversation_id` = `conversations`.`id` ORDER BY `created_at` DESC, `id` DESC LIMIT 1) = 'contact' THEN `target_user_id`
  ELSE NULL
END;
--> statement-breakpoint
UPDATE `messages`
SET `sender_id` = CASE WHEN `direction` = 'self'
  THEN COALESCE((SELECT `current_user_id` FROM `conversations` WHERE `id` = `messages`.`conversation_id`), '')
  ELSE COALESCE((SELECT `target_user_id` FROM `conversations` WHERE `id` = `messages`.`conversation_id`), '') END,
    `receiver_id` = CASE WHEN `direction` = 'self'
  THEN COALESCE((SELECT `target_user_id` FROM `conversations` WHERE `id` = `messages`.`conversation_id`), '')
  ELSE COALESCE((SELECT `current_user_id` FROM `conversations` WHERE `id` = `messages`.`conversation_id`), '') END;
--> statement-breakpoint
CREATE INDEX `conversations_participants_idx` ON `conversations` (`current_user_id`, `target_user_id`);
