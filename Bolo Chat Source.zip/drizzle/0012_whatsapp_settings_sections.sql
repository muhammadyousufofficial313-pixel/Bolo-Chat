ALTER TABLE `profiles` ADD COLUMN `security_notifications_enabled` integer DEFAULT 1 NOT NULL;
--> statement-breakpoint
ALTER TABLE `profiles` ADD COLUMN `call_tone` text DEFAULT 'noor' NOT NULL;
--> statement-breakpoint
ALTER TABLE `profiles` ADD COLUMN `auto_download_photos` integer DEFAULT 1 NOT NULL;
--> statement-breakpoint
ALTER TABLE `profiles` ADD COLUMN `auto_download_voice` integer DEFAULT 1 NOT NULL;
--> statement-breakpoint
CREATE TABLE `blocked_contacts` (
  `id` integer PRIMARY KEY AUTOINCREMENT NOT NULL,
  `target_user_id` text NOT NULL,
  `contact_name` text NOT NULL,
  `contact_email` text,
  `contact_username` text,
  `created_at` integer NOT NULL
);
--> statement-breakpoint
CREATE UNIQUE INDEX `blocked_contacts_target_idx` ON `blocked_contacts` (`target_user_id`);
--> statement-breakpoint
CREATE TABLE `chat_lists` (
  `id` integer PRIMARY KEY AUTOINCREMENT NOT NULL,
  `name` text NOT NULL,
  `created_at` integer NOT NULL
);
--> statement-breakpoint
CREATE TABLE `chat_list_members` (
  `id` integer PRIMARY KEY AUTOINCREMENT NOT NULL,
  `list_id` integer NOT NULL REFERENCES `chat_lists`(`id`) ON DELETE cascade,
  `target_user_id` text NOT NULL,
  `contact_name` text NOT NULL,
  `contact_email` text,
  `contact_username` text
);
--> statement-breakpoint
CREATE UNIQUE INDEX `chat_list_members_unique_idx` ON `chat_list_members` (`list_id`, `target_user_id`);
--> statement-breakpoint
CREATE TABLE `feedback` (
  `id` integer PRIMARY KEY AUTOINCREMENT NOT NULL,
  `body` text NOT NULL,
  `created_at` integer NOT NULL
);
