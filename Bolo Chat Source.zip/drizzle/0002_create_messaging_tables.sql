CREATE TABLE profiles (
  id INTEGER PRIMARY KEY NOT NULL,
  display_name TEXT NOT NULL,
  email TEXT NOT NULL,
  created_at INTEGER NOT NULL,
  updated_at INTEGER NOT NULL,
  CHECK (id = 1)
);
--> statement-breakpoint
CREATE TABLE conversations (
  id INTEGER PRIMARY KEY AUTOINCREMENT,
  contact_name TEXT NOT NULL,
  contact_email TEXT,
  created_at INTEGER NOT NULL,
  updated_at INTEGER NOT NULL
);
--> statement-breakpoint
CREATE TABLE messages (
  id INTEGER PRIMARY KEY AUTOINCREMENT,
  conversation_id INTEGER NOT NULL REFERENCES conversations(id) ON DELETE CASCADE,
  body TEXT NOT NULL,
  direction TEXT NOT NULL CHECK (direction IN ('self', 'contact')),
  created_at INTEGER NOT NULL
);
--> statement-breakpoint
CREATE INDEX messages_conversation_created_idx ON messages(conversation_id, created_at);
--> statement-breakpoint
CREATE INDEX conversations_updated_idx ON conversations(updated_at);
--> statement-breakpoint
DROP TABLE entries;
